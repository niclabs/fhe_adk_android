var searchData=
[
  ['makeirredpoly',['makeIrredPoly',['../_numb_th_8h.html#a5a97a87708a5be4df9307d13c9df9798',1,'NumbTh.cpp']]],
  ['mappingdata',['MappingData',['../class_mapping_data.html',1,'']]],
  ['maptoslots',['mapToSlots',['../class_p_algebra_mod_derived.html#a9e11cf0dd11db8daa0da4be1fd97d1ac',1,'PAlgebraModDerived']]],
  ['mat_5fmul',['mat_mul',['../class_encrypted_array_base.html#aff1318c7035e31e0aca82dbd1cc77d79',1,'EncryptedArrayBase::mat_mul(Ctxt &amp;ctxt, const PlaintextMatrixBaseInterface &amp;mat) const =0'],['../class_encrypted_array_base.html#a36a05e35cf90021dac9d380bf0124b8f',1,'EncryptedArrayBase::mat_mul(Ctxt &amp;ctxt, const PlaintextBlockMatrixBaseInterface &amp;mat) const =0'],['../class_encrypted_array_derived.html#a6bc4dd1bf5e00df5c7c70bffdd183114',1,'EncryptedArrayDerived::mat_mul(Ctxt &amp;ctxt, const PlaintextMatrixBaseInterface &amp;mat) const '],['../class_encrypted_array_derived.html#a6f09237e059834a59ed77592dce8982f',1,'EncryptedArrayDerived::mat_mul(Ctxt &amp;ctxt, const PlaintextBlockMatrixBaseInterface &amp;mat) const '],['../_encrypted_array_8h.html#afadddd02af4b74870b5e17a9d7a3ddbd',1,'mat_mul():&#160;EncryptedArray.cpp']]],
  ['mat_5fmul1d',['mat_mul1D',['../class_encrypted_array_base.html#a11f078b7eed37d6c1372aff9281f4908',1,'EncryptedArrayBase::mat_mul1D()'],['../class_encrypted_array_derived.html#aafb3e7c24ac2e6f8de5c8e85edacebf9',1,'EncryptedArrayDerived::mat_mul1D()'],['../_encrypted_array_8h.html#aa795e4099baa3f41b4a7e3bb23fc53d0',1,'mat_mul1D():&#160;EncryptedArray.cpp']]],
  ['mat_5fmul_5fdense',['mat_mul_dense',['../class_encrypted_array_base.html#a0e8a74bee3941da1f5c097e1b699eee5',1,'EncryptedArrayBase::mat_mul_dense()'],['../class_encrypted_array_derived.html#ab4dec23e3d1b92574971d4293f8f5d9c',1,'EncryptedArrayDerived::mat_mul_dense()'],['../_encrypted_array_8h.html#a9b77a4114eaf5e1db1f7c8d9fc51d85d',1,'mat_mul_dense():&#160;EncryptedArray.cpp']]],
  ['matching_2eh',['matching.h',['../matching_8h.html',1,'']]],
  ['maximum_5fflow',['maximum_flow',['../matching_8h.html#aa852be1b5ea042ce6e8047e53ba2d6ce',1,'matching.cpp']]],
  ['mcmod',['mcMod',['../_numb_th_8h.html#a752ff32e0774942d0411e0022d80277c',1,'NumbTh.cpp']]],
  ['mobius',['mobius',['../_numb_th_8h.html#aed2212168d62459736eb33482aa03c4f',1,'NumbTh.cpp']]],
  ['modcomp',['ModComp',['../_numb_th_8h.html#a353fb64d9105252fbde0ab147063a506',1,'NumbTh.cpp']]],
  ['moddowntolevel',['modDownToLevel',['../class_ctxt.html#a7947baccd9d1422968f6f84cc789b482',1,'Ctxt']]],
  ['moddowntoset',['modDownToSet',['../class_ctxt.html#a393fba128062930f79b364e60d6ada7a',1,'Ctxt']]],
  ['modp_5fdigpoly',['modP_digPoly',['../class_f_h_econtext.html#a4ae3796a85d9c6fde09ebf3445ea872e',1,'FHEcontext']]],
  ['modswitchaddednoisevar',['modSwitchAddedNoiseVar',['../class_ctxt.html#a5052c1d64bd87968415b6f89f7c8974b',1,'Ctxt']]],
  ['moduptoset',['modUpToSet',['../class_ctxt.html#ae907f977841484be6fe83df0ae26b190',1,'Ctxt']]],
  ['mul',['mul',['../class_s_k_handle.html#aedaccf4c19061bef92fbfca39d88079c',1,'SKHandle']]],
  ['mulmod',['MulMod',['../_numb_th_8h.html#ac209d82c1cbb2c9a1c06994b912ca976',1,'NumbTh.cpp']]],
  ['multbyp',['multByP',['../class_ctxt.html#a3473cf0a620be6f7441592a01cd56f05',1,'Ctxt']]],
  ['multord',['multOrd',['../_numb_th_8h.html#a7be07a4c8f732b42ba90dd1bbc115629',1,'NumbTh.cpp']]]
];
