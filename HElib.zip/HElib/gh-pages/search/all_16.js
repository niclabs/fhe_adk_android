var searchData=
[
  ['zmstar',['zMStar',['../class_f_h_econtext.html#a633aa885c07bd5bd0ea5f852979cfddd',1,'FHEcontext']]],
  ['zmstargen',['ZmStarGen',['../class_p_algebra.html#a7b5e459b55b412fdf0591df8b8215ffd',1,'PAlgebra']]],
  ['zz_5fpxmodulus1',['ZZ_pXModulus1',['../class_z_z__p_x_modulus1.html',1,'ZZ_pXModulus1'],['../classzz__p_x_modulus1.html',1,'zz_pXModulus1']]]
];
