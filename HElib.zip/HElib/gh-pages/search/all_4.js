var searchData=
[
  ['e',['e',['../class_recrypt_data.html#aa7c7a0cc2ca2e19d4e4daa811ce6a2c5',1,'RecryptData']]],
  ['ea',['ea',['../class_f_h_econtext.html#a213c8eb358214c776c437008d2413135',1,'FHEcontext::ea()'],['../class_recrypt_data.html#a90a78f94bfc2f8e685fae2e9d98c7755',1,'RecryptData::ea()']]],
  ['embedinallslots',['embedInAllSlots',['../class_p_algebra_mod_derived.html#a7366b2186923b8f412a43cd7c07f8a1f',1,'PAlgebraModDerived']]],
  ['embedinslots',['embedInSlots',['../class_p_algebra_mod_derived.html#a5c942a3231b23237f6b4f8da945c7ae1',1,'PAlgebraModDerived']]],
  ['emptyset',['emptySet',['../class_index_set.html#a14f651a36f2e4162585b768c1dbe62c1',1,'IndexSet']]],
  ['encode',['encode',['../class_plaintext_array_base.html#a3e9ef9c446223ca2a9c82c234f3d4c55',1,'PlaintextArrayBase::encode(const vector&lt; long &gt; &amp;array)=0'],['../class_plaintext_array_base.html#aa9380473b89593d0a5216961d9340763',1,'PlaintextArrayBase::encode(long val)=0'],['../class_plaintext_array_derived.html#ab091321967676bd0e1bc377a90d58a0f',1,'PlaintextArrayDerived::encode(const vector&lt; long &gt; &amp;array)'],['../class_plaintext_array_derived.html#aa89626dd14f3fcd333d392188b7e0c03',1,'PlaintextArrayDerived::encode(long val)'],['../class_plaintext_array.html#aea8b83b4f17ff18bfa8f87cd1ddc422e',1,'PlaintextArray::encode(const vector&lt; long &gt; &amp;array)'],['../class_plaintext_array.html#aa65ada5b3ba20a17dade3ac411e55262',1,'PlaintextArray::encode(long val)']]],
  ['encodeunitselector',['encodeUnitSelector',['../class_encrypted_array_base.html#aad027e0785a9667616f71815d56508c8',1,'EncryptedArrayBase::encodeUnitSelector()'],['../class_encrypted_array_derived.html#a8adbe02c902aec23ea1c9ae9b6afd33b',1,'EncryptedArrayDerived::encodeUnitSelector()']]],
  ['encrypt',['Encrypt',['../class_f_h_e_pub_key.html#aeb3e473d659de4e15438c72ff13671c5',1,'FHEPubKey::Encrypt()'],['../class_f_h_e_sec_key.html#ad3fff30aee84b17d0f9f5395be265b13',1,'FHESecKey::Encrypt()']]],
  ['encryptedarray',['EncryptedArray',['../class_encrypted_array.html',1,'EncryptedArray'],['../class_encrypted_array.html#af4ecda6a63d383e310ffd109a2dca555',1,'EncryptedArray::EncryptedArray(const FHEcontext &amp;context, const ZZX &amp;G=ZZX(1, 1))'],['../class_encrypted_array.html#a0f004123815bb36148c99be8738634e2',1,'EncryptedArray::EncryptedArray(const FHEcontext &amp;context, const PAlgebraMod &amp;_alMod)']]],
  ['encryptedarray_2eh',['EncryptedArray.h',['../_encrypted_array_8h.html',1,'']]],
  ['encryptedarraybase',['EncryptedArrayBase',['../class_encrypted_array_base.html',1,'']]],
  ['encryptedarrayderived',['EncryptedArrayDerived',['../class_encrypted_array_derived.html',1,'']]],
  ['equals',['equals',['../class_plaintext_array_base.html#a3f2c5340f58c27b3fecb94245bd00677',1,'PlaintextArrayBase::equals()'],['../class_plaintext_array_derived.html#a6a236693338d2e41cc5b5005500788b3',1,'PlaintextArrayDerived::equals()'],['../class_plaintext_array.html#aed6a1c5a89ae96c5595433ad3a05599a',1,'PlaintextArray::equals()']]],
  ['evalmap',['EvalMap',['../class_eval_map.html',1,'']]],
  ['evalmap_2eh',['EvalMap.h',['../_eval_map_8h.html',1,'']]],
  ['evalpoly',['evalPoly',['../class_ctxt.html#a3b09459a1b7c10ffd45f0602600f56ce',1,'Ctxt']]],
  ['exp',['Exp',['../class_double_c_r_t.html#a5add4b13040babfb49fea7faa58e4e6b',1,'DoubleCRT']]],
  ['exponentiate',['exponentiate',['../class_p_algebra.html#afd695877392605ee75e422e1a958485d',1,'PAlgebra']]],
  ['extractdigits',['extractDigits',['../_ctxt_8h.html#acf7202ea8a45561b724513be027c5b8d',1,'extractDigits.cpp']]]
];
