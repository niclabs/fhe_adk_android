var searchData=
[
  ['qgrpord',['qGrpOrd',['../class_p_algebra.html#a714909169581d0e8b76fb57b41c725d8',1,'PAlgebra']]]
];
