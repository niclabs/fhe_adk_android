var searchData=
[
  ['palgebra_2eh',['PAlgebra.h',['../_p_algebra_8h.html',1,'']]],
  ['permutations_2eh',['permutations.h',['../permutations_8h.html',1,'']]],
  ['polyeval_2eh',['polyEval.h',['../poly_eval_8h.html',1,'']]],
  ['powerful_2eh',['powerful.h',['../powerful_8h.html',1,'']]]
];
